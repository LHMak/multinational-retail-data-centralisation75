SELECT
	SUM(staff_numbers) AS total_staff_numbers,
	CASE
		WHEN country_code = 'N/A' THEN 'GB'
		ELSE country_code
	END AS country
FROM dim_store_details
GROUP BY country
ORDER BY SUM(staff_numbers) DESC;