SELECT
	ROUND(SUM(products.product_price * orders.product_quantity)::numeric,2) AS total_sales,
	dates.year,
	EXTRACT(MONTH FROM TO_DATE(month, 'Month')) AS "month"
FROM orders_table orders
JOIN dim_products products
	ON products.product_code = orders.product_code
JOIN dim_date_times dates
	ON dates.date_uuid = orders.date_uuid
GROUP BY dates.year, dates.month
ORDER BY ROUND(SUM(products.product_price * orders.product_quantity)::numeric,2) DESC
LIMIT 10;