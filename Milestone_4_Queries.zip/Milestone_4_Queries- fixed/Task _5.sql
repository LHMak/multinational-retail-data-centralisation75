SELECT
	store.store_type,
	ROUND(SUM(products.product_price * orders.product_quantity)::numeric,2) AS total_sales,
	ROUND((SUM(products.product_price * orders.product_quantity) /
	(
		SELECT SUM(dim_products.product_price * orders_table.product_quantity)
		FROM orders_table
		JOIN dim_products ON dim_products.product_code = orders_table.product_code
	) * 100)::numeric, 2) AS "percentage_total"
FROM orders_table orders
JOIN dim_products products
	ON products.product_code = orders.product_code
JOIN dim_store_details store
	ON store.store_code = orders.store_code
GROUP BY store.store_type
ORDER BY ROUND(SUM(products.product_price * orders.product_quantity)::numeric,2) DESC;