WITH cte AS(
	SELECT TO_TIMESTAMP(CONCAT(year, '-', EXTRACT(MONTH FROM TO_DATE(month, 'Month')), '-', day::text, ' ', timestamp), 'YYYY-MM-DD HH24:MI:SS') AS datetimes,
       year
	FROM dim_date_times
),

cte2 AS(
	SELECT
		year,
		datetimes,
	LEAD(datetimes, 1) OVER (ORDER BY datetimes DESC) AS time_difference
	FROM cte
),

cte3 AS (
	SELECT
		year, AVG((datetimes - time_difference)) as time_interval
	FROM cte2
	GROUP BY year
	ORDER BY AVG((datetimes - time_difference)) DESC
	LIMIT 5
)

SELECT
	year,
	CONCAT(
		'"hours": ', EXTRACT(HOUR FROM time_interval), ',',
		'"minutes": ', EXTRACT(MINUTE FROM time_interval),',',
		'"seconds": ', EXTRACT(SECOND FROM time_interval),',',
		'"milliseconds": ', EXTRACT(MILLISECOND FROM time_interval)
	) AS actual_time_taken
FROM cte3