SELECT
	SUM(staff_numbers) AS total_staff_numbers,
	country_code
FROM dim_store_details
WHERE country_code != 'N/A'
GROUP BY country_code
ORDER BY SUM(staff_numbers) DESC