SELECT
	ROUND(SUM(products.product_price * orders.product_quantity)::numeric,2) AS total_sales,
	store.store_type,
	store.country_code
FROM dim_store_details store
JOIN orders_table orders
	ON orders.store_code = store.store_code
JOIN dim_products products
	ON products.product_code = orders.product_code
WHERE store.country_code = 'DE'
GROUP BY store.country_code, store.store_type
ORDER BY ROUND(SUM(products.product_price * orders.product_quantity)::numeric,2) ASC