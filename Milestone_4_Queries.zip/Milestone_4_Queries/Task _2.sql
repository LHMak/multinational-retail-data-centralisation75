SELECT locality, count(locality) AS "total_no_stores" FROM dim_store_details
WHERE country_code != 'N/A'
GROUP BY locality
ORDER BY count(locality) DESC
LIMIT 7