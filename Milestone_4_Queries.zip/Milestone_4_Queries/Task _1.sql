SELECT country_code AS "country", count(country_code) AS "total_no_stores" FROM dim_store_details
WHERE country_code != 'N/A'
GROUP BY country_code